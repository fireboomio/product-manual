package org.jeecg.modules.common.test.enums;

import lombok.Getter;

// <#fileName#>enums/Freetalk_AppType<#fileName#>
public enum Freetalk_AppType {
    default("default"),
    insensitive("insensitive");

    @Getter
    private final String value;

    Freetalk_AppType(String value) {
        this.value = value;
    }
}