package org.jeecg.modules.common.test.Input;

import lombok.Data;

// <#fileName#>Input/Admin__AppVersion__CreateOneAppInput<#fileName#>
@Data
public class Admin__AppVersion__CreateOneAppInput {
    public Admin__AppVersion__CreateOneAppInput(org.jeecg.modules.common.test.enums.Freetalk_AppType type, String version, Boolean isForce, Boolean latest) {
        this.type = type;
        this.version = version;
        this.isForce = isForce;
        this.latest = latest;
    }
    private org.jeecg.modules.common.test.enums.Freetalk_AppType type;
    private String version;
    private Boolean isForce;
    private Boolean latest;
}