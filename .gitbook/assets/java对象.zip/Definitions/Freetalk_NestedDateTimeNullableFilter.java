package org.jeecg.modules.common.test.Definitions;

import lombok.Data;

// <#fileName#>Definitions/Freetalk_NestedDateTimeNullableFilter<#fileName#>
@Data
public class Freetalk_NestedDateTimeNullableFilter {
    public Freetalk_NestedDateTimeNullableFilter(String lt, String lte, org.jeecg.modules.common.test.Definitions.Freetalk_NestedDateTimeNullableFilter not, java.util.List<String> notIn, String equals, String gt, String gte, java.util.List<String> in) {
        this.lt = lt;
        this.lte = lte;
        this.not = not;
        this.notIn = notIn;
        this.equals = equals;
        this.gt = gt;
        this.gte = gte;
        this.in = in;
    }
    private String lt;
    private String lte;
    private org.jeecg.modules.common.test.Definitions.Freetalk_NestedDateTimeNullableFilter not;
    private java.util.List<String> notIn;
    private String equals;
    private String gt;
    private String gte;
    private java.util.List<String> in;
}