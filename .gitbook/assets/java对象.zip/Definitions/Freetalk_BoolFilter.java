package org.jeecg.modules.common.test.Definitions;

import lombok.Data;

// <#fileName#>Definitions/Freetalk_BoolFilter<#fileName#>
@Data
public class Freetalk_BoolFilter {
    public Freetalk_BoolFilter(Boolean equals, org.jeecg.modules.common.test.Definitions.Freetalk_NestedBoolFilter not) {
        this.equals = equals;
        this.not = not;
    }
    private Boolean equals;
    private org.jeecg.modules.common.test.Definitions.Freetalk_NestedBoolFilter not;
}