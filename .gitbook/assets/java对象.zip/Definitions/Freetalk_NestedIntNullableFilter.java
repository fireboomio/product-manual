package org.jeecg.modules.common.test.Definitions;

import lombok.Data;

// <#fileName#>Definitions/Freetalk_NestedIntNullableFilter<#fileName#>
@Data
public class Freetalk_NestedIntNullableFilter {
    public Freetalk_NestedIntNullableFilter(Integer equals, Integer gt, Integer gte, java.util.List<Integer> in, Integer lt, Integer lte, org.jeecg.modules.common.test.Definitions.Freetalk_NestedIntNullableFilter not, java.util.List<Integer> notIn) {
        this.equals = equals;
        this.gt = gt;
        this.gte = gte;
        this.in = in;
        this.lt = lt;
        this.lte = lte;
        this.not = not;
        this.notIn = notIn;
    }
    private Integer equals;
    private Integer gt;
    private Integer gte;
    private java.util.List<Integer> in;
    private Integer lt;
    private Integer lte;
    private org.jeecg.modules.common.test.Definitions.Freetalk_NestedIntNullableFilter not;
    private java.util.List<Integer> notIn;
}