package org.jeecg.modules.common.test.Definitions;

import lombok.Data;

// <#fileName#>Definitions/Freetalk_UuidFilter<#fileName#>
@Data
public class Freetalk_UuidFilter {
    public Freetalk_UuidFilter(String equals, String gt, java.util.List<String> in, org.jeecg.modules.common.test.Definitions.Freetalk_NestedUuidFilter not, String gte, String lt, String lte, org.jeecg.modules.common.test.enums.Freetalk_QueryMode mode, java.util.List<String> notIn) {
        this.equals = equals;
        this.gt = gt;
        this.in = in;
        this.not = not;
        this.gte = gte;
        this.lt = lt;
        this.lte = lte;
        this.mode = mode;
        this.notIn = notIn;
    }
    private String equals;
    private String gt;
    private java.util.List<String> in;
    private org.jeecg.modules.common.test.Definitions.Freetalk_NestedUuidFilter not;
    private String gte;
    private String lt;
    private String lte;
    private org.jeecg.modules.common.test.enums.Freetalk_QueryMode mode;
    private java.util.List<String> notIn;
}