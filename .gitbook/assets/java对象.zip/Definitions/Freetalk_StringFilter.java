package org.jeecg.modules.common.test.Definitions;

import lombok.Data;

// <#fileName#>Definitions/Freetalk_StringFilter<#fileName#>
@Data
public class Freetalk_StringFilter {
    public Freetalk_StringFilter(String endsWith, org.jeecg.modules.common.test.enums.Freetalk_QueryMode mode, org.jeecg.modules.common.test.Definitions.Freetalk_NestedStringFilter not, String startsWith, String contains, String equals, String gt, String gte, java.util.List<String> in, String lt, String lte, java.util.List<String> notIn) {
        this.endsWith = endsWith;
        this.mode = mode;
        this.not = not;
        this.startsWith = startsWith;
        this.contains = contains;
        this.equals = equals;
        this.gt = gt;
        this.gte = gte;
        this.in = in;
        this.lt = lt;
        this.lte = lte;
        this.notIn = notIn;
    }
    private String endsWith;
    private org.jeecg.modules.common.test.enums.Freetalk_QueryMode mode;
    private org.jeecg.modules.common.test.Definitions.Freetalk_NestedStringFilter not;
    private String startsWith;
    private String contains;
    private String equals;
    private String gt;
    private String gte;
    private java.util.List<String> in;
    private String lt;
    private String lte;
    private java.util.List<String> notIn;
}