package org.jeecg.modules.common.test.Definitions;

import lombok.Data;

// <#fileName#>Definitions/Freetalk_DateTimeNullableFilter<#fileName#>
@Data
public class Freetalk_DateTimeNullableFilter {
    public Freetalk_DateTimeNullableFilter(String equals, String gt, String gte, java.util.List<String> in, String lt, String lte, org.jeecg.modules.common.test.Definitions.Freetalk_NestedDateTimeNullableFilter not, java.util.List<String> notIn) {
        this.equals = equals;
        this.gt = gt;
        this.gte = gte;
        this.in = in;
        this.lt = lt;
        this.lte = lte;
        this.not = not;
        this.notIn = notIn;
    }
    private String equals;
    private String gt;
    private String gte;
    private java.util.List<String> in;
    private String lt;
    private String lte;
    private org.jeecg.modules.common.test.Definitions.Freetalk_NestedDateTimeNullableFilter not;
    private java.util.List<String> notIn;
}