package org.jeecg.modules.common.test.InternalInput;

import lombok.Data;

// <#fileName#>InternalInput/Admin__AppVersion__CreateOneAppInternalInput<#fileName#>
@Data
public class Admin__AppVersion__CreateOneAppInternalInput {
    public Admin__AppVersion__CreateOneAppInternalInput(String version, String createdAt, Boolean isForce, Boolean latest, org.jeecg.modules.common.test.enums.Freetalk_AppType type, String updatedAt) {
        this.version = version;
        this.createdAt = createdAt;
        this.isForce = isForce;
        this.latest = latest;
        this.type = type;
        this.updatedAt = updatedAt;
    }
    private String version;
    private String createdAt;
    private Boolean isForce;
    private Boolean latest;
    private org.jeecg.modules.common.test.enums.Freetalk_AppType type;
    private String updatedAt;
}