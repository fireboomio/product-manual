package org.jeecg.modules.common.test.ResponseData;

import lombok.Data;

// <#fileName#>ResponseData/App__GetLastVersionResponseData_android<#fileName#>
@Data
public class App__GetLastVersionResponseData_android {
    public App__GetLastVersionResponseData_android(String description, String downloadUrl, Boolean isForce, String version) {
        this.description = description;
        this.downloadUrl = downloadUrl;
        this.isForce = isForce;
        this.version = version;
    }
    private String description;
    private String downloadUrl;
    private Boolean isForce;
    private String version;
}