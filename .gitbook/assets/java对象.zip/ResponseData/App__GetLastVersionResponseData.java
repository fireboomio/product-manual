package org.jeecg.modules.common.test.ResponseData;

import lombok.Data;

// <#fileName#>ResponseData/App__GetLastVersionResponseData<#fileName#>
@Data
public class App__GetLastVersionResponseData {
    public App__GetLastVersionResponseData(org.jeecg.modules.common.test.ResponseData.App__GetLastVersionResponseData_android android, org.jeecg.modules.common.test.ResponseData.App__GetLastVersionResponseData_ios ios) {
        this.android = android;
        this.ios = ios;
    }
    private org.jeecg.modules.common.test.ResponseData.App__GetLastVersionResponseData_android android;
    private org.jeecg.modules.common.test.ResponseData.App__GetLastVersionResponseData_ios ios;
}