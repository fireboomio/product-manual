package org.jeecg.modules.common.test.ResponseData;

import lombok.Data;

// <#fileName#>ResponseData/App__GetAppListResponseData<#fileName#>
@Data
public class App__GetAppListResponseData {
    public App__GetAppListResponseData(java.util.List<org.jeecg.modules.common.test.ResponseData.App__GetAppListResponseData_data> data) {
        this.data = data;
    }
    private java.util.List<org.jeecg.modules.common.test.ResponseData.App__GetAppListResponseData_data> data;
}