package org.jeecg.modules.common.test.ResponseData;

import lombok.Data;

// <#fileName#>ResponseData/App__GetLastVersionResponseData_ios<#fileName#>
@Data
public class App__GetLastVersionResponseData_ios {
    public App__GetLastVersionResponseData_ios(String description, String downloadUrl, Boolean isForce, String version) {
        this.description = description;
        this.downloadUrl = downloadUrl;
        this.isForce = isForce;
        this.version = version;
    }
    private String description;
    private String downloadUrl;
    private Boolean isForce;
    private String version;
}