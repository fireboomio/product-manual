package org.jeecg.modules.common.test.ResponseData;

import lombok.Data;

// <#fileName#>ResponseData/App__GetAppListResponseData_data<#fileName#>
@Data
public class App__GetAppListResponseData_data {
    public App__GetAppListResponseData_data(String version, String description, String downloadUrl, Boolean isForce, Boolean latest, org.jeecg.modules.common.test.enums.Freetalk_AppType type) {
        this.version = version;
        this.description = description;
        this.downloadUrl = downloadUrl;
        this.isForce = isForce;
        this.latest = latest;
        this.type = type;
    }
    private String version;
    private String description;
    private String downloadUrl;
    private Boolean isForce;
    private Boolean latest;
    private org.jeecg.modules.common.test.enums.Freetalk_AppType type;
}