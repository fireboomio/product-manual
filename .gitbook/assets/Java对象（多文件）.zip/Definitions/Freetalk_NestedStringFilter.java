package com.fireboom.common.test.Definitions;

import lombok.Data;

// <#fileName#>Definitions/Freetalk_NestedStringFilter<#fileName#>
@Data
public class Freetalk_NestedStringFilter {
    public Freetalk_NestedStringFilter(String startsWith, String equals, String gt, String lt, String lte, java.util.List<String> notIn, String contains, String endsWith, String gte, java.util.List<String> in, com.fireboom.common.test.Definitions.Freetalk_NestedStringFilter not) {
        this.startsWith = startsWith;
        this.equals = equals;
        this.gt = gt;
        this.lt = lt;
        this.lte = lte;
        this.notIn = notIn;
        this.contains = contains;
        this.endsWith = endsWith;
        this.gte = gte;
        this.in = in;
        this.not = not;
    }
    private String startsWith;
    private String equals;
    private String gt;
    private String lt;
    private String lte;
    private java.util.List<String> notIn;
    private String contains;
    private String endsWith;
    private String gte;
    private java.util.List<String> in;
    private com.fireboom.common.test.Definitions.Freetalk_NestedStringFilter not;
}