package com.fireboom.common.test.Definitions;

import lombok.Data;

// <#fileName#>Definitions/Freetalk_NestedDateTimeFilter<#fileName#>
@Data
public class Freetalk_NestedDateTimeFilter {
    public Freetalk_NestedDateTimeFilter(com.fireboom.common.test.Definitions.Freetalk_NestedDateTimeFilter not, java.util.List<String> notIn, String equals, String gt, String gte, java.util.List<String> in, String lt, String lte) {
        this.not = not;
        this.notIn = notIn;
        this.equals = equals;
        this.gt = gt;
        this.gte = gte;
        this.in = in;
        this.lt = lt;
        this.lte = lte;
    }
    private com.fireboom.common.test.Definitions.Freetalk_NestedDateTimeFilter not;
    private java.util.List<String> notIn;
    private String equals;
    private String gt;
    private String gte;
    private java.util.List<String> in;
    private String lt;
    private String lte;
}