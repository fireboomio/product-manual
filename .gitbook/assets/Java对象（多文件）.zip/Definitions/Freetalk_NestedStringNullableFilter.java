package com.fireboom.common.test.Definitions;

import lombok.Data;

// <#fileName#>Definitions/Freetalk_NestedStringNullableFilter<#fileName#>
@Data
public class Freetalk_NestedStringNullableFilter {
    public Freetalk_NestedStringNullableFilter(com.fireboom.common.test.Definitions.Freetalk_NestedStringNullableFilter not, String contains, String gte, String gt, java.util.List<String> in, String lt, String lte, java.util.List<String> notIn, String startsWith, String endsWith, String equals) {
        this.not = not;
        this.contains = contains;
        this.gte = gte;
        this.gt = gt;
        this.in = in;
        this.lt = lt;
        this.lte = lte;
        this.notIn = notIn;
        this.startsWith = startsWith;
        this.endsWith = endsWith;
        this.equals = equals;
    }
    private com.fireboom.common.test.Definitions.Freetalk_NestedStringNullableFilter not;
    private String contains;
    private String gte;
    private String gt;
    private java.util.List<String> in;
    private String lt;
    private String lte;
    private java.util.List<String> notIn;
    private String startsWith;
    private String endsWith;
    private String equals;
}