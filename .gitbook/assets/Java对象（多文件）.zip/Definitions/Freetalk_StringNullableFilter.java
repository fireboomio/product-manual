package com.fireboom.common.test.Definitions;

import lombok.Data;

// <#fileName#>Definitions/Freetalk_StringNullableFilter<#fileName#>
@Data
public class Freetalk_StringNullableFilter {
    public Freetalk_StringNullableFilter(String contains, String equals, String gte, String lt, String endsWith, String gt, java.util.List<String> in, String lte, com.fireboom.common.test.enums.Freetalk_QueryMode mode, com.fireboom.common.test.Definitions.Freetalk_NestedStringNullableFilter not, java.util.List<String> notIn, String startsWith) {
        this.contains = contains;
        this.equals = equals;
        this.gte = gte;
        this.lt = lt;
        this.endsWith = endsWith;
        this.gt = gt;
        this.in = in;
        this.lte = lte;
        this.mode = mode;
        this.not = not;
        this.notIn = notIn;
        this.startsWith = startsWith;
    }
    private String contains;
    private String equals;
    private String gte;
    private String lt;
    private String endsWith;
    private String gt;
    private java.util.List<String> in;
    private String lte;
    private com.fireboom.common.test.enums.Freetalk_QueryMode mode;
    private com.fireboom.common.test.Definitions.Freetalk_NestedStringNullableFilter not;
    private java.util.List<String> notIn;
    private String startsWith;
}