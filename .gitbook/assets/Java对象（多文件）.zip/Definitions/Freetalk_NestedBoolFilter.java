package com.fireboom.common.test.Definitions;

import lombok.Data;

// <#fileName#>Definitions/Freetalk_NestedBoolFilter<#fileName#>
@Data
public class Freetalk_NestedBoolFilter {
    public Freetalk_NestedBoolFilter(Boolean equals, com.fireboom.common.test.Definitions.Freetalk_NestedBoolFilter not) {
        this.equals = equals;
        this.not = not;
    }
    private Boolean equals;
    private com.fireboom.common.test.Definitions.Freetalk_NestedBoolFilter not;
}