package com.fireboom.common.test.Input;

import lombok.Data;

// <#fileName#>Input/Admin__AppVersion__UpdateOneAppInput<#fileName#>
@Data
public class Admin__AppVersion__UpdateOneAppInput {
    public Admin__AppVersion__UpdateOneAppInput(String description, String downloadUrl, String id, Boolean isForce, Boolean latest, com.fireboom.common.test.enums.Freetalk_AppType type, String version) {
        this.description = description;
        this.downloadUrl = downloadUrl;
        this.id = id;
        this.isForce = isForce;
        this.latest = latest;
        this.type = type;
        this.version = version;
    }
    private String description;
    private String downloadUrl;
    private String id;
    private Boolean isForce;
    private Boolean latest;
    private com.fireboom.common.test.enums.Freetalk_AppType type;
    private String version;
}