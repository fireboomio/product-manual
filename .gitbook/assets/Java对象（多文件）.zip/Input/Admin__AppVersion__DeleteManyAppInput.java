package com.fireboom.common.test.Input;

import lombok.Data;

// <#fileName#>Input/Admin__AppVersion__DeleteManyAppInput<#fileName#>
@Data
public class Admin__AppVersion__DeleteManyAppInput {
    public Admin__AppVersion__DeleteManyAppInput(java.util.List<String> ids) {
        this.ids = ids;
    }
    private java.util.List<String> ids;
}