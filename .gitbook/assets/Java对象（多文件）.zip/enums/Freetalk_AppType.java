package com.fireboom.common.test.enums;

import lombok.Getter;

// <#fileName#>enums/Freetalk_AppType<#fileName#>
public enum Freetalk_AppType {
    Android("Android"),
    IOS("IOS");

    @Getter
    private final String value;

    Freetalk_AppType(String value) {
        this.value = value;
    }
}