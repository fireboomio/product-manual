package com.fireboom.common.test.InternalInput;

import lombok.Data;

// <#fileName#>InternalInput/Admin__AppVersion__DeleteManyAppInternalInput<#fileName#>
@Data
public class Admin__AppVersion__DeleteManyAppInternalInput {
    public Admin__AppVersion__DeleteManyAppInternalInput(java.util.List<String> ids) {
        this.ids = ids;
    }
    private java.util.List<String> ids;
}