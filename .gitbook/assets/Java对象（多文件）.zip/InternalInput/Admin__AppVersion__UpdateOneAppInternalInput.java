package com.fireboom.common.test.InternalInput;

import lombok.Data;

// <#fileName#>InternalInput/Admin__AppVersion__UpdateOneAppInternalInput<#fileName#>
@Data
public class Admin__AppVersion__UpdateOneAppInternalInput {
    public Admin__AppVersion__UpdateOneAppInternalInput(String version, String description, String downloadUrl, String id, Boolean isForce, Boolean latest, com.fireboom.common.test.enums.Freetalk_AppType type, String updateTime) {
        this.version = version;
        this.description = description;
        this.downloadUrl = downloadUrl;
        this.id = id;
        this.isForce = isForce;
        this.latest = latest;
        this.type = type;
        this.updateTime = updateTime;
    }
    private String version;
    private String description;
    private String downloadUrl;
    private String id;
    private Boolean isForce;
    private Boolean latest;
    private com.fireboom.common.test.enums.Freetalk_AppType type;
    private String updateTime;
}