package com.fireboom.common.test.InternalInput;

import lombok.Data;

// <#fileName#>InternalInput/Admin__AppVersion__CreateOneAppInternalInput<#fileName#>
@Data
public class Admin__AppVersion__CreateOneAppInternalInput {
    public Admin__AppVersion__CreateOneAppInternalInput(String version, String createdAt, Boolean isForce, Boolean latest, com.fireboom.common.test.enums.Freetalk_AppType type, String updatedAt) {
        this.version = version;
        this.createdAt = createdAt;
        this.isForce = isForce;
        this.latest = latest;
        this.type = type;
        this.updatedAt = updatedAt;
    }
    private String version;
    private String createdAt;
    private Boolean isForce;
    private Boolean latest;
    private com.fireboom.common.test.enums.Freetalk_AppType type;
    private String updatedAt;
}